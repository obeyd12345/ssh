# Documentation Moved

The documentation is now hosted on Facebook's Developer site:<br>
https://developers.facebook.com/docs/instant-articles/sdk/
